package com.ssafit.yus;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class YusapiApplication {
	public static void main(String[] args) {
		SpringApplication.run(YusapiApplication.class, args);
	}

}
