package com.ssafit.yus.model.service;

import java.util.List;

import com.ssafit.yus.model.dto.ExercisePerRoutine;

public interface ExercisePerRoutineService {
	List<ExercisePerRoutine> getAll();
}
